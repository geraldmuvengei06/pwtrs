import{l as n,M as e}from"./entry.3a59f98e.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
