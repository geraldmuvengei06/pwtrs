import{_ as m}from"./ProseCode.vue.25cfa263.js";import"./entry.3a59f98e.js";export{m as default};
