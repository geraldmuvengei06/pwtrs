import{y as s,z as n}from"./entry.3a59f98e.js";const r={__name:"index.backup",setup(o){const e=s();return n(()=>{e.push("/services/online-assignment-help")}),()=>{}}};export{r as default};
