const __slug__vue_vue_type_style_index_0_scoped_2f9290de_lang = "";

const __slug_Styles_ce026615 = [__slug__vue_vue_type_style_index_0_scoped_2f9290de_lang, __slug__vue_vue_type_style_index_0_scoped_2f9290de_lang];

export { __slug_Styles_ce026615 as default };
//# sourceMappingURL=_…slug_-styles.ce026615.mjs.map
