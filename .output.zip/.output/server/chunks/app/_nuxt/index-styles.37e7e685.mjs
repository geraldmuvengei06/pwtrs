const Hero_vue_vue_type_style_index_0_lang = "";

const indexStyles_37e7e685 = [Hero_vue_vue_type_style_index_0_lang];

export { indexStyles_37e7e685 as default };
//# sourceMappingURL=index-styles.37e7e685.mjs.map
