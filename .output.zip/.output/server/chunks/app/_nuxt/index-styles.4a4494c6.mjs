const index_vue_vue_type_style_index_0_scoped_5ffaeb1e_lang = "";

const indexStyles_4a4494c6 = [index_vue_vue_type_style_index_0_scoped_5ffaeb1e_lang, index_vue_vue_type_style_index_0_scoped_5ffaeb1e_lang];

export { indexStyles_4a4494c6 as default };
//# sourceMappingURL=index-styles.4a4494c6.mjs.map
