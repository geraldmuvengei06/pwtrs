const HowItWorksTimeline_vue_vue_type_style_index_0_scoped_fc3f52c8_lang = "@media screen and (max-width:960px){[data-v-fc3f52c8] .customized-timeline .p-timeline-event:nth-child(2n){flex-direction:row!important}[data-v-fc3f52c8] .customized-timeline .p-timeline-event:nth-child(2n) .p-timeline-event-content{text-align:left!important}[data-v-fc3f52c8] .customized-timeline .p-timeline-event-opposite{flex:0}[data-v-fc3f52c8] .customized-timeline .p-card{margin-top:1rem}}";

const indexStyles_5cd9a4ab = [HowItWorksTimeline_vue_vue_type_style_index_0_scoped_fc3f52c8_lang];

export { indexStyles_5cd9a4ab as default };
//# sourceMappingURL=index-styles.5cd9a4ab.mjs.map
