// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/services/best-essay-writing-service\":[\"content:services:best-essay-writing-service.md\"],\"/services/essay-assignments\":[\"content:services:essay-assignments.md\"],\"/services/online-assignment-help\":[\"content:services:online-assignment-help.md\"],\"/services/term-paper-writing-service\":[\"content:services:term-paper-writing-service.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
