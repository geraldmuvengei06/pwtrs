// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Services\",\"_path\":\"/services\",\"children\":[{\"title\":\"Essay Writing Service\",\"_path\":\"/services/best-essay-writing-service\"},{\"title\":\"Essay Assignments\",\"_path\":\"/services/essay-assignments\"},{\"title\":\"Online Assignment Help\",\"_path\":\"/services/online-assignment-help\"},{\"title\":\"Term Paper Writing Service\",\"_path\":\"/services/term-paper-writing-service\"}]}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
